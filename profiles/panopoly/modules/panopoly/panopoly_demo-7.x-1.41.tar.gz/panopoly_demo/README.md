Panopoly Demo
=============
Demo content and functionality to help show the power of Panopoly

Key features
* Demonstration homepage
* Demonstration content
* Demonstration Views/Panels Integration
* Demonstration pane and region styles
